$( document ).ready(function() {
    $("article.post").fitVids();
});